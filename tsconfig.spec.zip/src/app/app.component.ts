import { Component } from '@angular/core';
import { ProdService } from './services/prod.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  ar: string[] = [];
  constructor(private myServ: ProdService) {
    myServ.getdata().subscribe((res) => (this.ar = res));
    myServ.getdata().subscribe((res) => console.log(res));
  }
}
